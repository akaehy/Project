echo << test3.sh
