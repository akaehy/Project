case "$1" in
	[sS][tT][aA][rR][tT])
		echo "starting ..."
	;;
	stop)
		echo "stopping ..."
	;;
	*)
		echo "other command"
	;;
esac
