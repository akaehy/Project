#HELLO="hello world"

echo $HELLO
