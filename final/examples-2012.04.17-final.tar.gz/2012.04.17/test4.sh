HELLO="hello world"

export HELLO

echo $HELLO

sh test5.sh
