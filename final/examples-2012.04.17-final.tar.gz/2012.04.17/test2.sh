command1 &
command2
